# Singly Linked List in Python

This project demonstrates a simple implementation of a **singly linked list** in Python using Object-Oriented Programming (OOP).

## Features

- Add nodes to the end of the list
- Print the entire list
- Delete the nth node (1-based indexing)
- Handles edge cases like deleting from an empty list or deleting a node with an invalid index

## Usage

Run the Python script:

```bash
python linked_list.py
```

## Example Output

```
Added 10 as head node.
Added 20 to the end of the list.
Added 30 to the end of the list.
Added 40 to the end of the list.
Linked List: 10 -> 20 -> 30 -> 40 -> None
Deleted node at position 2 with value 20
Linked List: 10 -> 30 -> 40 -> None
Deleted head node with value 10
Linked List: 30 -> 40 -> None
Error: Index out of range.
Deleted head node with value 30
Deleted head node with value 40
Error: Cannot delete from an empty list.
```

## Author

Keshav Kumar Jha